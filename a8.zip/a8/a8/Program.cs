﻿public class pro
{
    public static void ain(String[] args)
    {

    }
}