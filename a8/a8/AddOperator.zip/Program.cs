﻿public class pro
{
    public static void Main(String[] args)
    {
        Console.WriteLine("eshgi seyyed!");
    }
}