﻿namespace A8;
public interface IOperator
{
    string OperatorSymbol { get; }
}
